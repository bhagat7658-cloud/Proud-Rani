# Proud Rani — Women’s Safety Movement

Clean Android MVP for Gen-Z of JKL.

### Included
- Proud Rani logo embedded as app icon and home branding
- Large SOS button
- 112 emergency dialer
- Core team call buttons
- WhatsApp helpline shortcut
- Location sharing via Android share sheet
- GitHub Actions workflow that builds the APK
- Java 17 + Android Gradle Plugin 8.7.3; no Firebase required for this MVP

### Important
The app intentionally uses the phone dialer/share sheet rather than silently placing calls or sending messages. The WhatsApp number is currently set to Anmol's number as a placeholder; change `WHATSAPP` in `MainActivity.java` when the official helpline number is finalized.

For GitHub: upload the contents of this folder to a NEW repository, then open Actions. The workflow should build `app-debug.apk` and attach it as an artifact.
