package com.genzofjkl.proudrani;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

public class SplashActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_splash);
        LinearLayout content = findViewById(R.id.splashContent);
        content.startAnimation(AnimationUtils.loadAnimation(this, R.anim.splash_fade));
        content.postDelayed(() -> {
            startActivity(new Intent(this, MainActivity.class));
            finish();
        }, 1800);
    }
}
